# Spring Boot Jasypt Demo
This repository is intended for showing how to encrypt sensitive variable, such as password in properties file.

More detail about how to use this repository, please visit http://www.ru-rocker.com/2017/01/13/spring-boot-encrypting-sensitive-variable-properties-file/
